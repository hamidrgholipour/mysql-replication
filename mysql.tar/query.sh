mysql -h 10.10.10.10 -P 31351 -uroot -p123 persons -e'select * from users;'
